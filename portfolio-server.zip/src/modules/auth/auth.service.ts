import jwt from "jsonwebtoken"
import httpStatus from "http-status"
import { User } from "./auth.model"
import type { ILoginUser, IUser, ILoginResponse } from "./auth.type"
import { AppError } from "../../middlewares/globalErrorHandler"

// Generate JWT token
const generateToken = (id: string): string => {
  return jwt.sign({ id }, process.env.JWT_SECRET as string, {
    expiresIn: process.env.JWT_EXPIRES_IN || "30d",
  })
}

// Register a new user
export const registerUser = async (userData: IUser): Promise<IUser> => {
  // Check if user already exists
  const existingUser = await User.findOne({ email: userData.email })
  if (existingUser) {
    throw new AppError("Email already in use", httpStatus.BAD_REQUEST)
  }

  // Check if there's already an admin user
  const adminExists = await User.findOne({ role: "admin" })
  if (adminExists) {
    throw new AppError("Admin user already exists. Only one admin is allowed.", httpStatus.BAD_REQUEST)
  }

  // Create new user
  const newUser = await User.create(userData)
  return newUser
}

// Login user
export const loginUser = async (loginData: ILoginUser): Promise<ILoginResponse> => {
  const { email, password } = loginData

  // Find user by email
  const user = await User.findOne({ email }).select("+password")
  if (!user) {
    throw new AppError("Invalid email or password", httpStatus.UNAUTHORIZED)
  }

  // Check if password is correct
  const isPasswordCorrect = await user.isPasswordCorrect(password)
  if (!isPasswordCorrect) {
    throw new AppError("Invalid email or password", httpStatus.UNAUTHORIZED)
  }

  // Generate token
  const token = generateToken(user._id.toString())

  return {
    token,
    user: {
      _id: user._id.toString(),
      name: user.name,
      email: user.email,
      role: user.role,
    },
  }
}

// Get current user
export const getCurrentUser = async (userId: string): Promise<IUser> => {
  const user = await User.findById(userId)
  if (!user) {
    throw new AppError("User not found", httpStatus.NOT_FOUND)
  }
  return user
}

// Update user profile
export const updateProfile = async (userId: string, updateData: Partial<IUser>): Promise<IUser> => {
  const user = await User.findByIdAndUpdate(userId, updateData, {
    new: true,
    runValidators: true,
  })

  if (!user) {
    throw new AppError("User not found", httpStatus.NOT_FOUND)
  }

  return user
}

