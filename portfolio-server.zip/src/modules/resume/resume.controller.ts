import type { Request, Response, NextFunction } from "express"
import httpStatus from "http-status"
import {
  createResume,
  getAllResumes,
  getActiveResume,
  getResumeById,
  updateResume,
  deleteResume,
  setResumeActive,
} from "./resume.service"
import { catchAsync } from "../../utils/catchAsync"

// Create a new resume
export const createResumeController = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  // Add file URL from upload
  if (req.file) {
    req.body.file = req.file.path
  } else {
    return res.status(httpStatus.BAD_REQUEST).json({
      status: "error",
      message: "Resume file is required",
    })
  }

  const resume = await createResume(req.body)

  res.status(httpStatus.CREATED).json({
    status: "success",
    message: "Resume uploaded successfully",
    data: resume,
  })
})

// Get all resumes
export const getAllResumesController = catchAsync(async (_req: Request, res: Response, _next: NextFunction) => {
  const resumes = await getAllResumes()

  res.status(httpStatus.OK).json({
    status: "success",
    data: resumes,
  })
})

// Get active resume
export const getActiveResumeController = catchAsync(async (_req: Request, res: Response, _next: NextFunction) => {
  const resume = await getActiveResume()

  if (!resume) {
    return res.status(httpStatus.NOT_FOUND).json({
      status: "error",
      message: "No active resume found",
    })
  }

  res.status(httpStatus.OK).json({
    status: "success",
    data: resume,
  })
})

// Get a single resume
export const getResumeController = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  const { id } = req.params
  const resume = await getResumeById(id)

  res.status(httpStatus.OK).json({
    status: "success",
    data: resume,
  })
})

// Update a resume
export const updateResumeController = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  const { id } = req.params

  // Add file URL if file was uploaded
  if (req.file) {
    req.body.file = req.file.path
  }

  const updatedResume = await updateResume(id, req.body)

  res.status(httpStatus.OK).json({
    status: "success",
    message: "Resume updated successfully",
    data: updatedResume,
  })
})

// Delete a resume
export const deleteResumeController = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  const { id } = req.params
  await deleteResume(id)

  res.status(httpStatus.OK).json({
    status: "success",
    message: "Resume deleted successfully",
  })
})

// Set a resume as active
export const setResumeActiveController = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  const { id } = req.params
  const resume = await setResumeActive(id)

  res.status(httpStatus.OK).json({
    status: "success",
    message: "Resume set as active successfully",
    data: resume,
  })
})

