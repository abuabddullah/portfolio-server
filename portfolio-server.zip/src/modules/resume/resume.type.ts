export interface IResume {
  _id?: string
  title: string
  file: string
  isActive: boolean
  createdAt?: Date
  updatedAt?: Date
}

