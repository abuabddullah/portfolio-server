import { z } from "zod";

export const createResumeZodSchema = z.object({
  body: z.object({
    title: z.string({
      required_error: "Title is required",
    }),
    isActive: z.boolean().optional(),
  }),
});

export const updateResumeZodSchema = z.object({
  body: z.object({
    title: z.string().optional,
    isActive: z.boolean().optional(),
  }),
});
