import mongoose, { Schema } from "mongoose"
import type { IResume } from "./resume.type"

const resumeSchema = new Schema<IResume>(
  {
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
    },
    file: {
      type: String,
      required: [true, "Resume file is required"],
    },
    isActive: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  },
)

// Pre-save middleware to ensure only one active resume
resumeSchema.pre("save", async function (next) {
  if (this.isActive) {
    // Set all other resumes to inactive
    await this.constructor.updateMany({ _id: { $ne: this._id } }, { isActive: false })
  }
  next()
})

export const Resume = mongoose.model<IResume>("Resume", resumeSchema)

