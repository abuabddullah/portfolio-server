import httpStatus from "http-status"
import { Resume } from "./resume.model"
import type { IResume } from "./resume.type"
import { AppError } from "../../middlewares/globalErrorHandler"

// Create a new resume
export const createResume = async (resumeData: IResume): Promise<IResume> => {
  const newResume = await Resume.create(resumeData)
  return newResume
}

// Get all resumes
export const getAllResumes = async (): Promise<IResume[]> => {
  const resumes = await Resume.find().sort({ createdAt: -1 })
  return resumes
}

// Get active resume
export const getActiveResume = async (): Promise<IResume | null> => {
  const resume = await Resume.findOne({ isActive: true })
  return resume
}

// Get a single resume by ID
export const getResumeById = async (id: string): Promise<IResume> => {
  const resume = await Resume.findById(id)

  if (!resume) {
    throw new AppError("Resume not found", httpStatus.NOT_FOUND)
  }

  return resume
}

// Update a resume
export const updateResume = async (id: string, updateData: Partial<IResume>): Promise<IResume> => {
  const resume = await Resume.findByIdAndUpdate(id, updateData, {
    new: true,
    runValidators: true,
  })

  if (!resume) {
    throw new AppError("Resume not found", httpStatus.NOT_FOUND)
  }

  return resume
}

// Delete a resume
export const deleteResume = async (id: string): Promise<void> => {
  const result = await Resume.findByIdAndDelete(id)

  if (!result) {
    throw new AppError("Resume not found", httpStatus.NOT_FOUND)
  }
}

// Set a resume as active
export const setResumeActive = async (id: string): Promise<IResume> => {
  // First, set all resumes to inactive
  await Resume.updateMany({}, { isActive: false })

  // Then, set the specified resume to active
  const resume = await Resume.findByIdAndUpdate(id, { isActive: true }, { new: true })

  if (!resume) {
    throw new AppError("Resume not found", httpStatus.NOT_FOUND)
  }

  return resume
}

