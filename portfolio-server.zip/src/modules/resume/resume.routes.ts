import express from "express"
import {
  createResumeController,
  getAllResumesController,
  getActiveResumeController,
  getResumeController,
  updateResumeController,
  deleteResumeController,
  setResumeActiveController,
} from "./resume.controller"
import { protect } from "../../middlewares/auth.middleware"
import { validateRequest } from "../../middlewares/validateRequest"
import { createResumeZodSchema, updateResumeZodSchema } from "./resume.zod"
import { uploadResume } from "../../middlewares/upload.middleware"

const router = express.Router()

// Public routes
router.get("/active", getActiveResumeController)

// Protected routes
router.use(protect)
router.post("/", uploadResume, validateRequest(createResumeZodSchema), createResumeController)
router.get("/", getAllResumesController)
router.get("/:id", getResumeController)
router.patch("/:id", uploadResume, validateRequest(updateResumeZodSchema), updateResumeController)
router.delete("/:id", deleteResumeController)
router.patch("/:id/set-active", setResumeActiveController)

export const resumeRoutes = router

